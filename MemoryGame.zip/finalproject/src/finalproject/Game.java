package finalproject;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;

public class Game extends JFrame implements ActionListener
{

	private static final long serialVersionUID = 1L;
	
	static JFrame MainMenu;
	JFrame game = new JFrame("Game");
	JLabel label;
	int[] btnID = new int[2];
	int[] btnValue = new int[2];
	JButton exitBtn;
	JButton menuBtn;
	ArrayList<Integer> gameList = new ArrayList<Integer>();
	int counter = 0;
	
	public Game(JFrame frame)
	{
		
	}

	public void start() 
	{

	}
	
	public void panel()
	{
		
	}
	
	public boolean matchMade() 
	{
		if (btnValue[0] == btnValue[1]) 
		{
			return true;
		}
		return false;
	}

	
	
	public void actionPerformed (ActionEvent e)
	{
	
	}
}
