package finalproject;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import static java.util.Collections.*;

public class Level3 extends Game implements ActionListener 
{ 
	private static final long serialVersionUID = 1L;

	private JButton[] tiles = new JButton[36];

	public Level3(JFrame frame) 
	{
		super(MainMenu);
		setTitle("MemoryGame");
		setSize(600, 600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		label = new JLabel("Level 3");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setVerticalAlignment(SwingConstants.CENTER);
		add(label, BorderLayout.NORTH);

		start();
		panel();
		setArrayListText();
		setVisible(true);
	}

	public void start() 
	{
		for (int i = 0; i < tiles.length; i++) 
		{
			tiles[i] = new JButton();
			tiles[i].setFont(new Font("Serif", Font.BOLD, 28));
			tiles[i].addActionListener(this);
		}
		exitBtn = new JButton("Exit");
		exitBtn.addActionListener(this);
		menuBtn = new JButton("Menu");
		menuBtn.addActionListener(this);
	}

	public void panel() 
	{
		Panel gamePnl = new Panel();
		gamePnl.setLayout(new GridLayout(6, 6));
		for (int i = 0; i < tiles.length; i++) 
		{
			gamePnl.add(tiles[i]);
		}

		Panel buttonPnl = new Panel();
		buttonPnl.add(menuBtn);
		buttonPnl.add(exitBtn);
		buttonPnl.setLayout(new GridLayout(1, 0));

		add(gamePnl, BorderLayout.CENTER);
		add(buttonPnl, BorderLayout.SOUTH);

	}

	public void setArrayListText() 
	{
		for (int i = 0; i < 2; i++) 
		{
			for (int j = 1; j < (tiles.length / 2) + 1; j++) 
			{
				gameList.add(j);
			}
		}
		shuffle(gameList);
	}


	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if (exitBtn == e.getSource()) 
		{
			System.exit(0);
		}
		if (menuBtn == e.getSource()) 
		{
			MainMenu x = new MainMenu();
			x.WelcomeMenu();
			setVisible(false);
		}
		for (int i = 0; i < tiles.length; i++) 
		{
			if (tiles[i] == e.getSource()) 
			{
				tiles[i].setText("" + gameList.get(i));
				tiles[i].setEnabled(false);
				counter++;
				if (counter == 3) 
				{
					if (matchMade()) 
					{
						tiles[btnID[0]].setEnabled(false);
						tiles[btnID[1]].setEnabled(false);
					} 
					else 
					{
						tiles[btnID[0]].setEnabled(true);
						tiles[btnID[0]].setText("");
						tiles[btnID[1]].setEnabled(true);
						tiles[btnID[1]].setText("");
					}
					counter = 1;
				}
				if (counter == 1) 
				{
					btnID[0] = i;
					btnValue[0] = gameList.get(i);
				}
				if (counter == 2) 
				{
					btnID[1] = i;
					btnValue[1] = gameList.get(i);
				}
			}
		}
	}
}