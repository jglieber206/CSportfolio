package finalproject;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainMenu implements ActionListener 
{
	private JFrame frame;
	private JLabel Welcome;
	private JLabel chooseLevel;
	private JButton QuitBtn;
	private JButton levelOneBtn;
	private JButton levelTwoBtn;
	private JButton levelThreeBtn;
	private JLabel space1;
	private JLabel space2;
	private JLabel space3;
	private JLabel space4;

	public static void main(String[] args) 
	{
		MainMenu x = new MainMenu();
		x.WelcomeMenu();
	}

	public void WelcomeMenu() 
	{
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(new Dimension(300, 300));
		BoxLayout boxLayout = new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS);
	    frame.setLayout(boxLayout);
		frame.setTitle("Matching Game");

		Welcome = new JLabel("Welcome to This Game");
		Welcome.setAlignmentX(Component.CENTER_ALIGNMENT);
		chooseLevel = new JLabel("please choose your level");
		chooseLevel.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		QuitBtn = new JButton("Quit");
		QuitBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
		levelOneBtn = new JButton("Level 1");
		levelOneBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
		levelTwoBtn = new JButton("Level 2");
		levelTwoBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
		levelThreeBtn = new JButton("Level 3");
		levelThreeBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

		
		space1 = new JLabel(" ");
		space2 = new JLabel(" ");
		space3 = new JLabel(" ");
		space4 = new JLabel(" ");
		
		QuitBtn.addActionListener(this);
		levelOneBtn.addActionListener(this);
		levelTwoBtn.addActionListener(this);
		levelThreeBtn.addActionListener(this);

		frame.add(Welcome);
		frame.add(chooseLevel);
		frame.add(space1);
		frame.add(levelOneBtn);
		frame.add(space2);
		frame.add(levelTwoBtn);
		frame.add(space3);
		frame.add(levelThreeBtn);
		frame.add(space4);
		frame.add(QuitBtn);

		frame.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource() == levelOneBtn) 
		{
			frame.setVisible(false);
			new Level1(frame);
		} 
		else if (e.getSource() == levelTwoBtn)
		{
			frame.setVisible(false);
			new Level2(frame);
		}
		else if (e.getSource() == levelThreeBtn)
		{
			frame.setVisible(false);
			new Level3(frame);
		}
		else 
		{
			System.exit(0);
		}
	}
}