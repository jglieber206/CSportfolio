
public class NPC3 extends NPC{

	public NPC3(int x, int y) {
		super(x,y);
		myX = x;
		myY = y;
		myXVel = 20;
		myXSize = 20;
		myXSize = 15;
	}
	
	public void draw() {
		StdDraw.setPenColor(StdDraw.BLUE);
		StdDraw.filledRectangle(myX, myY, myXSize, myYSize);
	}
	
	public void move() {
		if(myX <= 30 || myX > canvasSize-30) {
			myXVel *= -1;
		}
		myX =+ myXVel;
	}
	
	public void fireMissile() {
		Missile m = new Missile(myX, myY + 2, 3);
		m.draw();
		m.move();
	}
}

