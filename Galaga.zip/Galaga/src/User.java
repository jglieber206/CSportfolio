import java.awt.event.KeyEvent;


public class User extends Ship{
	
	public User() {
		super(250,450);
		myXVel = 10;
		myXSize = 30;
		myYSize = 30;
		isUser = true;
		timer = 20;
	}
	
	public void draw() {
		if(isAlive) {
			StdDraw.setPenColor(StdDraw.RED);
			StdDraw.filledSquare(myX, myY, myXSize);
			StdDraw.setPenColor(StdDraw.BLACK);
			StdDraw.filledRectangle(myX-20, myY-15, 11, 16);
			StdDraw.filledRectangle(myX+20, myY-15, 11, 16);
		}
	}
	
	public void move() {
		if(StdDraw.isKeyPressed(KeyEvent.VK_LEFT)) {
			myX -= myXVel;
			//System.out.println("Is this working? - left");
		}
		if(StdDraw.isKeyPressed(KeyEvent.VK_RIGHT)) {
			myX += myXVel;
			//System.out.println("Is this working? - right");
		}
	}
	
	public void fireMissile() {
		if(StdDraw.isKeyPressed(KeyEvent.VK_SPACE) && timer <= 20) {
			timer = 0;
			Missile m = new Missile(myX, myY - 30, 3);
			m.draw();
			m.move();
		}
	}
	
	
}