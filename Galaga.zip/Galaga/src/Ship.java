
public class Ship extends Shape{
	
	//default constructor
	public Ship(int x, int y) {
		super(x,y);
	}
	
	public void draw() {
		
	}
	public void move() {
		
	}
	public void fireMissile() {
		
	}
}
