
public abstract class Shape {
	protected int myX;
	protected int myY;
	protected int myXSize;
	protected int myYSize;
	protected int myXVel;
	protected int myYVel;
	public int timer;
	protected boolean isAlive = true;
	public int canvasSize = 500;
	protected boolean isUser;
	
	public Shape() {
		myX = (int)(Math.random()*canvasSize);
		myY = (int)(Math.random()*canvasSize);
	}
	
	public Shape(int x, int y) {
		myX = x;
		myY = y;
	}
	
	public abstract void draw();
	public abstract void move();
	
	//Getters for shape variables
	public int getMyX() {
		return myX;
	}
	public int getMyY() {
		return myY;
	}
	public int getMyXVel() {
		return myXVel;
	}
	public int getMyYVel() {
		return myYVel;
	}
	public int getXSize() {
		return myXSize;
	}
	public int getYSize() {
		return myYSize;
	}
	public boolean isAlive() {
		return isAlive;
	}

	
}
