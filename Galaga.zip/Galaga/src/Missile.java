
public class Missile extends Shape {
	
	
	public Missile() {
		super();
	}
	
	public Missile(int x, int y, int yvel) {
		myX = x;
		myY = y;
		myYVel = yvel;
	}
	
	public void draw(){
		StdDraw.setPenColor(StdDraw.RED);
		StdDraw.filledRectangle(myX, myY, 3, 15);
	}
	
	public void move() {
		if(isUser) {
			myY -= myYVel;
		}
		else {
			myY += myYVel;
		}
	}
	
	public boolean intersect(Missile m, Ship s) {
		if(m.getMyX() >= s.getMyX()-s.getXSize() && m.getMyX() <= s.getMyX() + s.getXSize()
				&& m.getMyY() == s.getMyY() + s.getYSize()) {
			return true;
		}
		else {
			return false;
		}
	}
}
