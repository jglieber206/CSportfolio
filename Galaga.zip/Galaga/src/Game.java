import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;


public class Game {
	
	
	public static void main(String[] args) {
		int canvasSize = 500;
		StdDraw.setCanvasSize(canvasSize,canvasSize);
		StdDraw.setXscale(0,canvasSize);
		StdDraw.setYscale(canvasSize,0);
		StdDraw.setPenColor(StdDraw.BLACK);
		StdDraw.filledSquare(250, 250, canvasSize);
		
		ArrayList<Shape> theShape = new ArrayList<Shape>();
		//draw stars
		for(int i=0; i< 50; i++) {
			Shape star = new Stars();
			theShape.add(star);
		}		
		//npc 1
		for(int i=0; i<4; i++) {
			Shape one = new NPC1(i*canvasSize/4, canvasSize/6);
			theShape.add(one);
		}
		//npc 2
		for(int i=0; i<3; i++) {
			Shape two = new NPC2(i*canvasSize/3, canvasSize/5);
			theShape.add(two);
		}
		
		//npc 3
		for(int i=0; i< 8; i++) {
			Shape three = new NPC3(i*canvasSize/8, canvasSize/4);
			theShape.add(three);
		}
		
		//draw user ship
		Shape a = new User();
		theShape.add(a);
		
		while(true) {
			StdDraw.clear(StdDraw.BLACK);

			Iterator<Shape> it = theShape.iterator();
			while(it.hasNext()) {
				Shape s = it.next();
				s.draw();
				s.move();
			}
			StdDraw.show(20);
		}
		
		
	}
	
}
