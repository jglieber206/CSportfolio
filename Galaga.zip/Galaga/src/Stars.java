
public class Stars extends Shape {

	public Stars() {
		super();
		myYVel = 10;
	}
	
	
	public void draw() {
		StdDraw.setPenColor(StdDraw.WHITE);
		StdDraw.filledCircle(myX, myY, 3);
	}
	
	public void move() {
		if(myY > canvasSize){
			myY = 0;
		}
		myY += myYVel;
	}
}
