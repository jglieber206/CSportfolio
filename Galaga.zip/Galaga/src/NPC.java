
public abstract class NPC extends Ship{
	
	public NPC(int x, int y) {
		super(x,y);
		isUser = false;
		timer = 15;
	}

	public void fireMissile() {
		
	}
	
	public abstract void draw();
	
	public abstract void move();
	
	public void setX(int x) {
		myX = x;
	}
	public void setY(int y) {
		myY = y;
	}
	
}
