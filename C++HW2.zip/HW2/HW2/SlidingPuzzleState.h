//
//  SlidingPuzzleState.h
//  HW2
//
//  Jace Lieberman, Laura Meckley
//  Extra help from Aihui Yu
//  Copyright (c) 2015 Jace Lieberman. All rights reserved.
//

#ifndef __HW2__SlidingPuzzleState__
#define __HW2__SlidingPuzzleState__
#include <list>
#include <stdio.h>
#include "LList.h"

class SlidingPuzzleState
{
public:
    SlidingPuzzleState(const int tiles[12]);
    void GetMoves(LList<int> &l);
    bool ApplyMove(int move);
    bool UndoMove(int move);
    int GetTileInSquare(int row, int col);
    void GetEmptySquare(int &row, int &col);
    void Print();
    SlidingPuzzleState *Clone();
    bool IsSolution();
private:
    struct Board {
        int tileValue[12];
    };
    //    int **TwoDArray;
    LList<int> list;
    Board myBoard;
};

#endif /* defined(__HW2__SlidingPuzzleState__) */
