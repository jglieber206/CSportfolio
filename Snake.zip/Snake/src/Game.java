
public class Game 
{
	private Snake mySnake;
	private int score;
	private Fruit myFruit;
	
	public Game()
	{
		mySnake = new Snake();
		myFruit = new Fruit();
		score = 0;
	}
	
	public void init()
	{
		StdDraw.setCanvasSize(500, 500);
		StdDraw.setXscale(0, 500);
		StdDraw.setYscale(500, 0);
	}
	
	public void run()
	{
		while(true)
		{
			StdDraw.clear();
			
			mySnake.move();
			mySnake.draw();
			mySnake.handleKeyboard();
			
			if(mySnake.eatFruit(myFruit))
			{
				myFruit = new Fruit();
			}
			
			if( mySnake.eatSelf())
			{
				break;
			}
			myFruit.draw();
			
			StdDraw.show(100);
		}
	}
	
	
	

}
