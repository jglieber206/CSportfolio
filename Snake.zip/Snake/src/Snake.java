import java.util.ArrayList;

public class Snake 
{
	
	private ArrayList<Link> links;
	
	public Snake()
	{
		links = new ArrayList<Link>();
		
		//Add a head
		links.add(new Head(250, 250));
	}
	
	public void draw()
	{
		for(int i=0; i < links.size(); i++)
		{
			links.get(i).draw();
		}
	}
	
	public void move()
	{
		for(int i=links.size()-1; i >= 0; i-- )
		{
			links.get(i).move();
		}
	}

	public void handleKeyboard()
	{
		if( links.get(0) instanceof Head)
		{
			((Head)links.get(0)).handleKeyboard();
		}
	}
	
	public boolean isTouchingFruit(Fruit f)
	{
		Head h = (Head)links.get(0);
		int dx = f.getX() - h.getX();
		int dy = f.getY() - h.getY();
		double distance = Math.sqrt( dx * dx + dy * dy);

		return distance <= h.getLength() + f.getLength()/2;
	}
	
	public void createLink()
	{
		links.add( new Body(links.get(links.size()-1)));
	}
	
	public boolean eatFruit(Fruit f)
	{
		if( isTouchingFruit(f))
		{
			createLink();
			return true;
		}
		return false;
	}
	
	public boolean eatSelf()
	{
		for(int i=1; i < links.size(); i++)
		{
			return links.get(0).intersectLink(links.get(i));
		}
		return false;
	}
}
