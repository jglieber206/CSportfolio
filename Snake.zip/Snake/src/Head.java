import java.awt.event.KeyEvent;
public class Head extends Link
{
	private int direction; //0: up, 1: right, 2:down, 3:left
	
	public Head(int someX, int someY)
	{
		super(someX, someY);
	}
	
	public void move()
	{
		switch(direction)
		{
		case 0: 
			setY( getY() - getVelocity());
			break;
		case 1:
			setX( getX() + getVelocity());
			break;
		case 2:
			setY( getY() + getVelocity());
			break;
		case 3:
			setX( getX() - getVelocity());
		
		}
	}
	
	public void handleKeyboard()
	{
		if(StdDraw.isKeyPressed(KeyEvent.VK_W))
		{
			direction = 0;
		}
		else if(StdDraw.isKeyPressed(KeyEvent.VK_D))
		{
			direction = 1;
		}
		else if(StdDraw.isKeyPressed(KeyEvent.VK_S))
		{
			direction = 2;
		}
		else if(StdDraw.isKeyPressed(KeyEvent.VK_A))
		{
			direction = 3;
		}
	}
}
