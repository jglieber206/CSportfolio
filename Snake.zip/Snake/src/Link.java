
public abstract class Link 
{
	private int x;
	private int y;
	
	private int vel;

	public Link(int someX, int someY)
	{
		x = someX;
		y = someY;
		vel = 20;
	}
	
	public int getX()
	{
		return x;
		
	}
	
	public int getY()
	{
		return y;
	}
	
	public void setX(int newX)
	{
		x = newX;
	}
	
	public void setY(int newY)
	{
		y = newY;
	}
	
	public void setVelocity(int newv)
	{
		vel = newv;
	}
	
	public int getVelocity()
	{
		return vel;
	}
	
	public void draw()
	{
		StdDraw.circle(x, y, 10);
	}

	public abstract void move();
	
	public int getLength()
	{
		return 10;
	}
	
	public boolean intersectLink(Link l)
	{
		int dx = this.x - l.x;
		int dy = this.y - l.y;
		double distance = Math.sqrt(dx* dx + dy * dy);
		System.out.println(distance);
		return distance < getLength()+l.getLength();
			
	}
}
