
public class Fruit 
{
	private int x;
	private int y;
	
	public Fruit()
	{
		x = (int) (Math.random() * 400 + 50);
		y = (int) (Math.random() * 400 + 50);
	}
	
	public void draw()
	{
		StdDraw.square(x, y, 10);
	}
	
	public int getLength()
	{
		return 10;
	}
	
	public int getX()
	{
		return x;
	}
	
	public int getY()
	{
		return y;
	}
	
}
