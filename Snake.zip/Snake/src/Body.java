
public class Body extends Link
{
	private Link frontLink;
	
	public Body(Link fl)
	{
		super(-50, -50);
		this.frontLink = fl;
	}
	
	public void move()
	{
		setX( frontLink.getX());
		setY( frontLink.getY());
	}
	
}
